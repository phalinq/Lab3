﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Lab3;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.UserSecrets;
using Npgsql;

namespace Lab3.Model;
/**
 * Name: Quinton Phalin
 * Date: 10/2/2023
 * Description: Updated verion of lab 2
 * Bugs: I was able to create the table in the database, though
 *       the app tended to crash when trying to add insert
 * Reflection: I spent too much time trying to fix my issues from lab2, which I 
 *             was able to finally do, rather than working on the SQL for this lab. I also 
 *             should have started a little earlier because I wasn't anticipating to 
 *             have as many issues with Visual Studio as I did.
 */
public class Database : IDatabase
{
    private ObservableCollection<Airport> airports = new ObservableCollection<Airport>();
    private string connString = GetConnectionString();

    public Database()
    {
        CreateTable(connString);
    }
    static String GetConnectionString()
    {
        var connStringBuilder = new NpgsqlConnectionStringBuilder();
        connStringBuilder.Host = "eerie-trout-13108.5xj.cockroachlabs.cloud";
        connStringBuilder.Port = 26257;
        connStringBuilder.SslMode = SslMode.VerifyFull;
        connStringBuilder.Username = "quinton"; 
        connStringBuilder.Password = FetchPassword();
        connStringBuilder.Database = "defaultdb";
        connStringBuilder.ApplicationName = "Lab3"; 
        connStringBuilder.IncludeErrorDetail = true;
        return connStringBuilder.ConnectionString;
    }

    static String FetchPassword()
    {
        IConfiguration config = new ConfigurationBuilder().AddUserSecrets<Database>().Build();
        return config["CockroachDBPassword"] ?? "";
    }

    static void CreateTable(string connString)
    {
        using var conn = new NpgsqlConnection(connString);
        conn.Open();
        new NpgsqlCommand("CREATE TABLE IF NOT EXISTS airports (id VARCHAR(4) PRIMARY KEY, city VARCHAR(25), date TIMESTAMP, rating INT)", conn).ExecuteNonQuery();
    }

    public ObservableCollection<Airport> SelectAllAirports()
    {
        airports.Clear();
        var conn = new NpgsqlConnection(connString);
        conn.Open();
       
        using var cmd = new NpgsqlCommand("SELECT id, city, date, rating FROM airports", conn);
        using var reader = cmd.ExecuteReader(); 
        while (reader.Read()) 
        {
            String id = reader.GetString(0);
            String city = reader.GetString(1);
            DateTime date = reader.GetDateTime(2);
            Int32 rating = reader.GetInt32(3);
            Airport airportToAdd = new(id, city, date, rating);
            airports.Add(airportToAdd);
            Console.WriteLine(airportToAdd);
        }
        return airports;
    }

    public Airport SelectAirport(String id)
    {
        Airport airport = null;
        var conn = new NpgsqlConnection(connString);
        conn.Open();
       
        using var cmd = new NpgsqlCommand("SELECT id, city, date, rating FROM airports WHERE id = @id", conn);
        using var reader = cmd.ExecuteReader(); 
        while (reader.Read()) 
        {
            
                String Id = reader.GetString(0);
                String city = reader.GetString(1);
                DateTime date = reader.GetDateTime(2);
                Int32 rating = reader.GetInt32(3);
                airport = new Airport(id, city, date, rating);
        }
        //Returns either the airport if found or null if not
        return airport;
    }
    public String InsertAirport(Airport airport)
    {
        try
        {
            Console.WriteLine("Start");
            using var conn = new NpgsqlConnection(connString); 
            conn.Open(); 
            var cmd = new NpgsqlCommand(); 
            cmd.Connection = conn; 
            cmd.CommandText = "INSERT INTO airports (id, city, date, rating) VALUES (@id, @city, @date, @rating)";
            cmd.Parameters.AddWithValue("id", airport.Id);
            cmd.Parameters.AddWithValue("city", airport.City);
            cmd.Parameters.AddWithValue("date", airport.DateVisited);
            cmd.Parameters.AddWithValue("rating", airport.Ratings);
            cmd.ExecuteNonQuery(); 
            SelectAllAirports();
        }
        catch (Npgsql.PostgresException pe)
        {
            return string.Format("Insert failed, {0}", pe);
        }
        return null;
    }
    public String DeleteAirport(String id)
    {
        var conn = new NpgsqlConnection(connString);
        conn.Open();
        using var cmd = new NpgsqlCommand();
        cmd.Connection = conn;
        cmd.CommandText = "DELETE FROM airports WHERE id = @imdbId";
        cmd.Parameters.AddWithValue("id", id);
        int numDeleted = cmd.ExecuteNonQuery();
        if (numDeleted > 0)
        {
            SelectAllAirports(); 
            return null;
        }
        return "Problem occured!!!!!"; 
    }
    public String UpdateAirport(Airport airport)
    {
        try
        {
            using var conn = new NpgsqlConnection(connString);
            conn.Open(); 
            var cmd = new NpgsqlCommand(); 
            cmd.Connection = conn; 
            cmd.CommandText = "UPDATE airports SET city = @title, date = @year, rating = @numStars WHERE id = @imdbId;";
            cmd.Parameters.AddWithValue("id", airport.Id);
            cmd.Parameters.AddWithValue("city", airport.City);
            cmd.Parameters.AddWithValue("date", airport.DateVisited);
            cmd.Parameters.AddWithValue("rating", airport.Ratings);
            var numAffected = cmd.ExecuteNonQuery();
            SelectAllAirports();
        }
        catch (Npgsql.PostgresException pe)
        {
            return string.Format("Update failed, {0}", pe);
        }
        return "Error accessing file"; //File doesn't exist, or there was an issue accessing it
    }
}

