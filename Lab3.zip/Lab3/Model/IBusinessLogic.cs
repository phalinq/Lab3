﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab3.Model;

namespace Lab3.Model;

public interface IBusinessLogic
{
    ObservableCollection<Airport> Airports { get; }
    String AddAirport(String id, String city, DateTime dateVisited, int rating);
    String DeleteAirport(String id);
    String EditAirport(String id, String city, DateTime dateVisited, int rating);
    Airport FindAirport(String id);
    String CalculateStatistics();
    ObservableCollection<Airport> GetAirports();
}


