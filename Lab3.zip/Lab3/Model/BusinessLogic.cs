﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using Lab3;

namespace Lab3.Model;

public class BusinessLogic : IBusinessLogic
{
    private IDatabase database;
    public ObservableCollection<Airport> Airports
    {
        get { return database.SelectAllAirports(); }
    }

    private const int Bronze = 42;
    private const int Silver = 84;
    private const int Gold = 125;

    public BusinessLogic()
    {
        database = new Database();
    }

    public String AddAirport(String id, String city, DateTime dateVisited, int rating)
    {
        //The following conditionals check the inputs obtained in the UI class
        if (id.Length < 3 || id.Length > 4)
        {
            //Invalid id; either too short or too long
            return "Invalid id; id entered is not 3-4 characters";
        }
        if (city.Length > 25)
        {
            //Invalid city; too long
            return "Invalid City entered; too many characters entered";
        }
        if (rating < 1 || rating > 5)
        {
            //Invalid rating; either less than 1 or more than 5
            return "Invalid Rating; rating entered is not in the range of 1-5";
        }
        if (FindAirport(id) != null)
        {
            //Can't add airport as one with the same id already exists
            return "An airport with this id already exists\n" +
                "Either modify the existing airport or try again with a different id";
        }
        //Create an airport object and add it to the database
        Airport airport = new Airport();
        airport.Id = id;
        airport.City = city;
        airport.DateVisited = dateVisited;
        airport.Ratings = rating;
        Console.WriteLine("Insert call");
        String result = database.InsertAirport(airport);
        //If an error occurs in the database, the message is returned here
        return result;
    }
    public String DeleteAirport(String id)
    {
        //Checks to make sure the id is valid and that the airport actually exists first
        //An error message is returned if there are any issues
        if (id.Length < 3 || id.Length > 4)
        {
            return "Invalid id; id entered is not 3 - 4 characters";
        }
        if (FindAirport(id) == null)
        {
            return "Airport not found";
        }

        //If everything is good, the airport is deleted from the database
        //If any errors occur, the corresponding message is returned
        String result = database.DeleteAirport(id);
        return result;
    }
    public String EditAirport(String id, String city, DateTime dateVisited, int rating)
    {
        //Just like when adding a new airport, check to make sure the given info is valid
        if (id.Length < 3 || id.Length > 4)
        {
            return "Invalid id; id entered is not 3-4 characters";
        }
        if (city.Length > 25)
        {
            return "Invalid City entered; too many characters entered";
        }
        if (rating < 1 || rating > 5)
        {
            return "Invalid Rating; rating entered is not in the range of 1-5";
        }
        if (FindAirport(id) == null)
        {
            return "Airport not found";
        }

        //Assuming it looks good and the airport exists, proceed to the database
        //class to update the chosen airport
        Airport airport = FindAirport(id);
        airport.City = city;
        airport.DateVisited = dateVisited;
        airport.Ratings = rating;
        String result = database.UpdateAirport(airport);
        return result; //Returns a message if an error occured
    }
    public Airport FindAirport(String id)
    {
        //Finds a specific airport, if it exists 
        GetAirports();
        return database.SelectAirport(id);
    }
    public String CalculateStatistics()
    {
        //Gets the total number of airports visited
        ObservableCollection<Airport> airports = GetAirports();
        int total = airports.Count;
        String print = "";
        int remaining;

        //The following conditionals return a string that tells the user how many airports
        //have been visited and how many are remaining until reaching the next tier in the program
        if (total == 1)
        {
            print = "1 airport visited; 41 remaining until acheiving Bronze";
        }
        else if (total < Bronze)
        {
            remaining = Bronze - total;
            print = total + " airport visited; " + remaining + " remaining until acheiving Bronze";
        }
        else if (total < Silver)
        {
            remaining = Silver - total;
            print = total + " airport visited; " + remaining + " remaining until acheiving Silver";
        }
        else if (total < Gold)
        {
            remaining = Gold - total;
            print = total + " airport visited; " + remaining + " remaining until acheiving Gold";
        }
        else
        {
            print = "All 125 airports visited";
        }
        //Returns the message that will be printed
        return print;
    }
    public ObservableCollection<Airport> GetAirports()
    {
        //Gets a ObservableCollection of all of the airports from the database
        return database.SelectAllAirports();
    }
}

