﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3.Model;

public interface IDatabase
{
    ObservableCollection<Airport> SelectAllAirports();
    Airport SelectAirport(String id);
    String InsertAirport(Airport airport);
    String DeleteAirport(String id);
    String UpdateAirport(Airport airport);
}


