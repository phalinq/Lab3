﻿using System.ComponentModel;
using System.Runtime.Remoting;

namespace Lab3.Model;

public class Airport : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler PropertyChanged;
    String id;
    String city;
    DateTime dateVisited;
    int ratings;

    public String Id
    {
        get { return id; }
        set
        {
            id = value;
            OnPropertyChanged(nameof(Id));
        }
    }

    public String City
    {
        get { return city; }
        set
        {
            city = value;
            OnPropertyChanged(nameof(City));
        }
    }

    public DateTime DateVisited
    {
        get { return dateVisited; }
        set
        {
            dateVisited = value;
            OnPropertyChanged(nameof(DateVisited));
        }
    }

    public int Ratings
    {
        get { return ratings; }
        set { ratings = value; }
    }

    protected void OnPropertyChanged(String name)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

    public Airport() : this("KATW", "Appleton", DateTime.Now, 5) { }
    public Airport(String id, String city, DateTime dateVisited, int rating)
    {
        Id = id;
        City = city;
        DateVisited = dateVisited;
        Ratings = rating;
    }

    override public bool Equals(Object obj)
    {
        if (obj is Airport)
        {
            Airport temp = (Airport)obj;
            if (temp.Id.Equals(Id))
            {
                return true;
            }
        }
        return false;
    }
}

