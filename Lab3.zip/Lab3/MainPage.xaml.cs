﻿using static Android.Graphics.ColorSpace;

namespace Lab3;
using Microsoft.VisualBasic;

using System.Runtime.Intrinsics.X86;
using Model;
using Lab3;

public partial class MainPage : ContentPage
{

    public MainPage()
    {
        InitializeComponent();

        BindingContext = MauiProgram.BusinessLogic;
    }

    private void Add(object sender, EventArgs e)
    {
        //Checks the entered information to see if it's valid
        //If it is, then the airport is added. If not, an error message is displayed
        string id = IdENT.Text;
        string city = CityENT.Text;
        //DateTime date;
        if (DateTime.TryParse(DateENT.Text, out DateTime date))
        {
            if (int.TryParse(RatingENT.Text, out int rating))
            {
                String result = MauiProgram.BusinessLogic.AddAirport(id, city, date, rating);
                if (result != null)
                {
                    DisplayAlert("Error Adding Airport", result, "Ok");
                }
            }
            else
            {
                DisplayAlert("Invalid Entry", "Rating entered is not an integer", "Okay");
            }
        }
        else
        {
            DisplayAlert("Invalid Entry", "Date entered was not a valid date", "Okay");
        }
    }

    private void Edit(object sender, EventArgs e)
    {
        // Checks the entered information to see if it's valid
        //If it is, then the airport is edited. If not, an error message is displayed
        Airport airport = CV.SelectedItem as Airport;
        if (airport == null)
        {
            DisplayAlert("Error Editing", "Select an airport", "Okay");
        }
        else
        {
            String city = CityENT.Text;
            if (DateTime.TryParse(DateENT.Text, out DateTime date))
            {
                if (int.TryParse(RatingENT.Text, out int rating))
                {

                    String result = MauiProgram.BusinessLogic.EditAirport(airport.Id, city, date, rating);
                }
                else
                {
                    //Issue with the given rating
                    DisplayAlert("Invalid Entry", "Rating entered is not an integer", "Okay");
                }
            }
            else
            {
                //Issue with the given date
                DisplayAlert("Invalid Entry", "Date entered was not a valid date", "Okay");
            }
        }
    }

    private void Delete(object sender, EventArgs e)
    {
        //Attempts to delete an airport, prints a message if there is an error
        Airport airport = CV.SelectedItem as Airport;
        if (airport == null)
        {
            DisplayAlert("Error Deleting", "Select an airport", "Okay");
        }
        else
        {
            String results = MauiProgram.BusinessLogic.DeleteAirport(airport.Id);
            if (results != null)
            {
                DisplayAlert("Error Deleting", results, "Okay");
            }
        }
    }
}
